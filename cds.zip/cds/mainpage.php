<?php 
session_start();
error_reporting(1);
include('connection.php');
?>
<html>
<title>StoreMyResult.com</title>
<head>
<style>
.button {
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button1 {background-color: #4CAF50;}
.button2 {background-color: #008CBA;} 

</style>
</head>
<body >
<marquee><h1 style="color:rgb(3, 3, 3);font-size:500%;">!!!!!WELCOME TO STORE MY RESULTS</h1></marquee>
<br>
<center><img src="img1.png" width="300px"></center>
<center><h3><q>With data collection, ‘the sooner the better’ is always the best answer.</q></h3></center>
<center><h2 style="background-color:rgb(159, 209, 20);">To go next page you have to click on Login</h2><center>
<br><br><br>
<button class="button button2" onclick="window.location='Registation form.php'">REGISTER</button>
<button class="button button1" onclick="window.location='login.php'">LOGIN</button>
</body>
</html>