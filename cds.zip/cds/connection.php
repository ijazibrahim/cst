<?php 
$con=mysqli_connect("localhost","root","","cst") or die('DATABASE connection failed');

?>